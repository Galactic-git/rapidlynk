package config

const (
	MaxUploadSize = 100 << 20 // 100MB
)
