package main

import (
	"archive/tar"
	"compress/gzip"
	"os"
	"path/filepath"
)

func createArchive(output string) error {
	file, err := os.Create(output)
	if err != nil {
		return err
	}
	defer file.Close()

	gw := gzip.NewWriter(file)
	defer gw.Close()

	tw := tar.NewWriter(gw)
	defer tw.Close()

	root, _ := os.Getwd()

	return filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() && info.Name() == ".git" {
			return filepath.SkipDir
		}

		header, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return err
		}

		header.Name, _ = filepath.Rel(root, path)

		if err := tw.WriteHeader(header); err != nil {
			return err
		}

		if info.Mode().IsRegular() {
			f, _ := os.Open(path)
			defer f.Close()
			_, err = f.WriteTo(tw)
			return err
		}

		return nil
	})
}
