package main

import "fmt"

func handlePush() {
	archive := "rapidlynk_bundle.tar.gz"

	fmt.Println("📦 Bundling project...")
	createArchive(archive)

	fmt.Println("☁️ Uploading...")
	link, err := uploadFile(archive)
	if err != nil {
		fmt.Println("Upload failed:", err)
		return
	}

	fmt.Println("✅ Share this link:")
	fmt.Println(link)
}
