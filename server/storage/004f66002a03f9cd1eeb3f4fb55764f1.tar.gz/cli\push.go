package main

import (
	"fmt"
	"strings"
)

func handlePush() {
	archive := "rapidlynk_bundle.tar.gz"

	fmt.Println("📦 Bundling project...")
	createArchive(archive)

	fmt.Println("☁️ Uploading...")
	id, err := uploadFile(archive)
	if err != nil {
		fmt.Println("Upload failed:", err)
		return
	}

	id = strings.TrimSpace(id)

	fmt.Println("✅ Share this id:")
	fmt.Println(id)
}
