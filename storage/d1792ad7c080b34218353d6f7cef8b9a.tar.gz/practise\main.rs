fn main(){   
    let x:i2 = 1;
    println!("{}",x);
}