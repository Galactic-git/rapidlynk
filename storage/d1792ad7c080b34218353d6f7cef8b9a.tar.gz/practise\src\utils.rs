pub fn is_even(x:i32)->bool{
    return x%2 == 0;
}