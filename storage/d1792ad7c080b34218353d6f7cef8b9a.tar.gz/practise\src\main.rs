

enum Shape {
    Circle(f64),
    Square(f64),
}

fn get_area(shape:Shape)->f64{
    let ans = match shape{

        Shape::Circle(r)=> std::f64::consts::PI*r*r,
        Shape::Square(a)=> a*a,
    };
    return ans;


}


fn main() {
    let circle = Shape::Circle(2.0);
    let _square = Shape::Square(3.0);



    println!("areaof the square {}",get_area(circle) );
    println!("area of the square {}", get_area(_square));
    
}

