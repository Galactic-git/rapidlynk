// src/Ai_Process/analyzeWithOpenAI.ts
import OpenAI from "openai";
import "dotenv/config";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

/**
 * Analyze a full email bundle:
 *  - metadata (subject, body, sender, dates…)
 *  - all parsed attachments
 *  - schema instructions
 */

export async function analyzeWithOpenAI(
  finalBundle: {
    metadata: any;
    attachments: {
      filename: string;
      parsedText: string | any;
    }[];
  },
  jsonSchemaDescription: string   // <-- YOU WILL PASS YOUR JSON STRUCTURE HERE
): Promise<any> {

  try {
    console.log("🧠 Preparing email + attachments for OpenAI...");

    const { metadata, attachments } = finalBundle;

    // -----------------------------------------------------------
    // 1️⃣ Build attachment text (merge all parsed attachment text)
    // -----------------------------------------------------------
    const attachmentsText = attachments.length
      ? attachments.map(att => `
     Attachment: ${att.filename}
--------------------------------
${typeof att.parsedText === "string" ? att.parsedText : JSON.stringify(att.parsedText)}
`).join("\n\n")
      : "No attachments found.";

    // -----------------------------------------------------------
    // 2️⃣ Build email metadata text
    // -----------------------------------------------------------
    const emailText = `
📧 EMAIL METADATA
--------------------------------
Subject: ${metadata.subject}
From: ${metadata.from?.address || "unknown"}
Received: ${metadata.receivedDateTime}

📜 EMAIL BODY
--------------------------------
${metadata.body?.content || metadata.bodyPreview || "(No body)"}
`;

    // -----------------------------------------------------------
    // 3️⃣ Final prompt for OpenAI
    // -----------------------------------------------------------
    const prompt = `
You are an expert document & email understanding AI.

You will receive:

1. The EMAIL metadata + body.
2. The PARSED TEXT of all ATTACHMENTS (PDFs).
3. A JSON SCHEMA describing the final output format.

Your job:
- Understand the body + attachment content together.
- Extract all required fields.
- Return a **VALID JSON ONLY**, matching the schema exactly.

--------------------------------
📘 JSON SCHEMA TO FOLLOW
--------------------------------
${jsonSchemaDescription}

--------------------------------
📧 EMAIL CONTENT
--------------------------------
${emailText}

--------------------------------
📎 ATTACHMENTS CONTENT
--------------------------------
${attachmentsText}

Return ONLY valid JSON. No explanations, no markdown.
`;

    console.log("🧠 Sending bundle to OpenAI…");

    console.log("Prompt:   imp imp  ......->", prompt);

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    console.log("✅ OpenAI response received. and its usage is :", response.usage);

    const jsonText = response.choices[0].message?.content;
    const result = JSON.parse(jsonText || "{}");

    console.log("✅ AI extracted structured data:", result);
    return result;

  } catch (error: any) {
    console.error("❌ Error analyzing:", error.message);
    return { error: error.message };
  }
}

