// import path from "path";
// import fs from "fs";
// import chokidar from "chokidar";
// import { fileURLToPath } from "url";
// import { LlamaParseReader } from "llama-cloud-services";
// import "dotenv/config";
// import { analyzeWithOpenAI } from "./ai_analyze";
// import { uploadToCloudinary } from "../utils/cloudinaryUpload";
// import {jsonSchemaDescription } from "../descriptive_json";

// // Resolve paths
// const __filename = fileURLToPath(import.meta.url);
// const __dirname = path.dirname(__filename);

// const uploadsDir = path.resolve(__dirname, "../../uploads");
// const completedDir = path.resolve(__dirname, "../../completed");

// // Ensure folders exist
// if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
// if (!fs.existsSync(completedDir)) fs.mkdirSync(completedDir, { recursive: true });

// console.log("👀 Watching folder for new files:", uploadsDir);

// const watcher = chokidar.watch(uploadsDir, {
//   persistent: true,
//   ignoreInitial: false,
//   awaitWriteFinish: {
//     stabilityThreshold: 1500,
//     pollInterval: 100,
//   },
// });

// // Track processed folders
// const processedFolders = new Set<string>();

// watcher.on("add", async (filePath) => {
//   const fileName = path.basename(filePath);
//   const folderPath = path.dirname(filePath);
//   const emailFolder = path.basename(folderPath);

//   console.log(`🆕 File detected: ${fileName} in folder ${emailFolder}`);

//   // Skip if folder already processed
//   if (processedFolders.has(emailFolder)) {
//     console.log(`⏩ Folder ${emailFolder} already locked, skipping`);
//     return;
//   }

//   // Check if folder still exists
//   if (!fs.existsSync(folderPath)) {
//     console.log(`⚠ Folder missing (maybe moved already): ${folderPath}`);
//     return;
//   }

//   // Read folder contents
//   const files = fs.readdirSync(folderPath);
//   const hasMeta = files.includes("meta.json");

//   if (!hasMeta) {
//     console.log(`⏳ meta.json not yet present → waiting`);
//     return;
//   }

//   // Do not lock folder until meta.json exists
//   processedFolders.add(emailFolder);
//   console.log(`🔒 Folder locked for processing: ${emailFolder}`);

//   try {
//     console.log(`📂 Full folder contents:`, files);

//     const metaPath = path.join(folderPath, "meta.json");
//     const metadata = JSON.parse(fs.readFileSync(metaPath, "utf8"));

//     console.log(`📝 Loaded metadata for mail: ${metadata.id}`);

//     // Collect PDF attachments
//     const attachments = files.filter(f => f !== "meta.json");

//     console.log(`📎 Attachments found:`, attachments);

//     // LlamaParse reader
//     const reader = new LlamaParseReader({
//       apiKey: process.env.LLAMA_CLOUD_API_KEY,
//       resultType: "markdown",
//     });

//     // Parse all attachments
//     let parsedAttachments = [];

//     for (const pdf of attachments) {
//       const pdfPath = path.join(folderPath, pdf);

//       console.log(`🤖 Parsing attachment: ${pdf}`);

//       const docs = await reader.loadData(pdfPath);

//       const combinedText = Array.isArray(docs)
//         ? (docs as any[]).map(d => (d && (d as any).text) || "").join("\n")
//         : ((docs as any)?.text || "");

//       parsedAttachments.push({
//         filename: pdf,
//         parsedText: combinedText,
//       });
//     }

//     console.log(`🧩 Parsed all attachments. Count = ${parsedAttachments.length}`);

//     // Build final prompt object
//     const finalBundle = {
//       metadata,
//       attachments: parsedAttachments,
//     };

//     console.log("🔍 Sending combined bundle to OpenAI...");


//     console.log("finalBundle:", finalBundle);
//     const analysis = await analyzeWithOpenAI(finalBundle , jsonSchemaDescription);
//     console.log("✅ OpenAI response:", analysis);

//     // Upload original PDFs to Cloudinary
//     for (const pdf of attachments) {
//       const pdfPath = path.join(folderPath, pdf);
//       console.log(`☁️ Uploading ${pdf} to Cloudinary...`);

//       const url = await uploadToCloudinary(pdfPath);
//       console.log(`☁️ Uploaded: ${url}`);
//     }

//     // Move folder → completed
//     const dest = path.join(completedDir, emailFolder);
//     fs.renameSync(folderPath, dest);

//     console.log(`📁 Folder moved to completed → ${dest}`);
//     console.log("======================================================");

//   } catch (err) {
//     console.error(`❌ Error processing folder ${emailFolder}:`, err);
//   }
// });
